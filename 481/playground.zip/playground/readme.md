Запустить сервер
```
node server.js
```
