function callback() {
    // ваше решение
}

// инициализация класса чата с вашим коллбеком
const chat = new Chat(callback)
