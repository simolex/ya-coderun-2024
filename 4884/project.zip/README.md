```
nvm install
nvm use
npm install
```