declare module '*.eot';
declare module '*.ttf';
declare module '*.woff';
declare module '*.woff2';
