import path from "path";

export const hehehe = {
    test: /\.hehehe$/,
    type: "json"
};
