module.exports = async function result(
    socket,
    transmitters = [],
    {
        shortSignalPause = 500,
        longSignalPause = 1000,
        charPause = 200,
        wordPause = 2000,
    }
) {
    //code here
};
