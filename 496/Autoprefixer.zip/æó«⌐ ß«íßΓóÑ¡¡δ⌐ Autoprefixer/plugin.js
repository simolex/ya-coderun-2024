module.exports = (opts = {vendorPrefixes: {}}) => {
  // Ваш плагин
};

module.exports.postcss = true;